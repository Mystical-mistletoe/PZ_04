﻿namespace BankAccount_Task1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <symmary>
/// Банковский счет.
/// реализует
/// IComparable<BankAccount> (сортировка по балансу)
/// ICloneable (глубокое клонирование)
/// IDisposable (освобождение подключения)
/// IEquatable<BankAccount> (сравнение по номеру счета)
/// </symmary>

public class BankAccount : IComparable<BankAccount>, ICloneable, IDisposable, IEquatable<BankAccount>
{
    private readonly string _accountNumber;
    private readonly string _owner;
    private readonly BankConnection _connection;
    private decimal _balance;
    private bool _disposed;

    /// <summary>
    /// Создание банковского счета и открытие подключения
    /// </summary>
    /// <param name="accountNumber">Номер счета</param>
    /// <param name="owner">Владелец</param>
    /// <param name="startingBalance">баланс, не может быть отрицательным</param>
    public BankAccount(string accountNumber, string owner, decimal startingBalance)
    {
        if (string.IsNullOrEmpty(accountNumber))
        { 
            throw new ArgumentNullException("Номер счета не может быть пустым", nameof(accountNumber)); 
        }
        if (string.IsNullOrEmpty(owner)) 
        {
            throw new ArgumentNullException("Владелец счета не может быть пустым", nameof(owner)); 
        }
        if (startingBalance < 0)
        {
            throw new ArgumentException("Начальный баланс не может быть отрицательным.", nameof(startingBalance));
        }
        _accountNumber = accountNumber.Trim();
        _owner = owner.Trim();
        _balance = startingBalance;
        _connection = new BankConnection("https://bank.example.ru/api");
    }

    /// <summary>
    /// Создает глубокую копию счета
    /// </summary>
    /// <param name="source">исходный счет</param>
    public BankAccount(BankAccount source)
    {
        _accountNumber = source._accountNumber;
        _owner = source._owner;
        _balance = source._balance;
        _connection = source._connection.Clone();

    }

    public string AccountNumber => _accountNumber;
    public string Owner => _owner;

    /// <summary>
    /// текущий баланс счета
    /// </summary>
    public decimal Balance
    {  
        get 
        {
            ThrowIfDisposed();
            return _balance; 
        } 
    }

    /// <summary>
    /// подключение к банку
    /// </summary>
    public BankConnection Connection
    {
        get 
        {
            ThrowIfDisposed();
            return _connection;
        }
    }

    public bool IsConnectionOpen => !_disposed && _connection.IsOpen;

    /// <summary>
    /// пополняет счет
    /// </summary>
    public bool Deposit(decimal amount)
    {
        ThrowIfDisposed();

        if (amount <= 0)
        {
            return false;
        }

        _balance += amount;
        return true;
    }

    /// <summary>
    /// снятие суммы со счета
    /// </summary>
    /// <param name="amount">больше нуля, не больше баланса</param>
    /// <returns></returns>
    public bool Withdraw(decimal amount)
    {
        ThrowIfDisposed();

        if (amount <= 0 || amount > _balance)
        {
            return false;
        }

        _balance -= amount;
        return true;
    }

    /// <summary>
    /// сравнение счетов по балансу
    /// </summary>
    /// <param name="other"></param>
    /// <returns>отр число, ноль, полож число</returns>
    public int CompareTo(BankAccount? other)
    {
        if (other == null)
        {
            return 1;
        }
        return _balance.CompareTo(other._balance);
    }

    /// <summary>
    /// глубокая копия счета
    /// </summary>
    /// <returns>новый независимый</returns>
    public object Clone()
    {
        ThrowIfDisposed();
        return new BankAccount(this);
    }

    /// <summary>
    /// Сравнивает счета по номеру
    /// </summary>
    /// <param name="other">счет для сравнения</param>
    /// <returns>true, если совпадают</returns>
    public bool Equals(BankAccount? other)
    {
        if (other is null)
        {
            return false;
        }

        if (ReferenceEquals(this, other))
        {
            return true;
        }

        return string.Equals(_accountNumber, other._accountNumber, StringComparison.OrdinalIgnoreCase);
    }
    /// <summary>
    /// делегирует типизированному методу
    /// </summary>
    /// <param name="obj"></param>
    /// <returns>если объект является таким же </returns>
    public override bool Equals(object? obj)
    {
        return Equals(obj as BankAccount);
    }

    /// <summary>
    /// Возвращает хеш-код на основе номера счета.
    /// </summary>
    public override int GetHashCode()
    {
        return StringComparer.OrdinalIgnoreCase.GetHashCode(_accountNumber);
    }

    /// <summary>
    ///  если счета равны
    /// </summary>
    public static bool operator ==(BankAccount? left, BankAccount? right)
    {
        return object.Equals(left, right);
    }

    /// <summary>
    /// если счета не равны
    /// </summary>
    public static bool operator !=(BankAccount? left, BankAccount? right)
    {
        return !object.Equals(left, right);
    }

    /// <summary>
    /// если баланс левого счета меньше
    /// </summary>
    public static bool operator <(BankAccount left, BankAccount right)
    {
        return left.CompareTo(right) < 0;
    }

    /// <summary>
    /// если баланс левого счета больше
    /// </summary>
    public static bool operator >(BankAccount left, BankAccount right)
    {
        return left.CompareTo(right) > 0;
    }

    /// <summary>
    /// true, если баланс левого счета не больше
    /// </summary>
    public static bool operator <=(BankAccount left, BankAccount right)
    {
        return left.CompareTo(right) <= 0;
    }

    /// <symmary>
    /// true, если баланс левого счета не меньше
    /// </symmary>
    public static bool operator >=(BankAccount left, BankAccount right)
    {
        return left.CompareTo(right) >= 0;
    }

    /// <summary>
    /// освобождает ресурс, повторный вызов безопасен за счет проверки
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _connection.Close();
        _disposed = true;
    }

    /// <summary>Возвращает строковое представление счета.</summary>
    /// <returns>Номер счета, владелец и баланс.</returns>
    public override string ToString()
    {
        return $"{_accountNumber} | {_owner} | {_balance:N2} Р";
    }

    /// <summary>
    /// Проверяет, что счет еще не освобожден.
    /// </summary>
    private void ThrowIfDisposed()
    {
        if (_disposed)
        {
            throw new ObjectDisposedException(nameof(BankAccount));
        }
    }
}
