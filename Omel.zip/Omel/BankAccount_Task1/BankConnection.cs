﻿namespace BankAccount_Task1;
using System;

/// <summary>
/// Подключение к серсеру банка. Для глубокого клонирования, освобождения ресурса.
/// </summary>
public class BankConnection
{
    private static int _lastId;
    /// <summary>
    /// Создает новое подключение к банку
    /// </summary>
    /// <param name="endpoint">Адрес сервера банка</param>
    /// <exception cref="ArgumentException"></exception>
    public BankConnection(string endpoint)
    {
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            throw new ArgumentException(
                "Адрес банковского сервера не может быть пустым.",
                nameof(endpoint));
        }

        Id = Interlocked.Increment(ref _lastId);
        Endpoint = endpoint;
        IsOpen = true;
    }
    // уникальный номер подключения
    public int Id { get; }

    // адрес банковского сервера
    public string Endpoint { get; }

    // подключение открыто
    public bool IsOpen { get; private set; }

    // закрытие подключения
    public void Close()
    {
        IsOpen = false;
    }

    /// <summary>
    /// Создается независимая копия подключения к серверу
    /// </summary>
    /// <returns>возвращает новое подключение к тому же серверу</returns>
    public BankConnection Clone()
    {
        return new BankConnection(Endpoint);
    }
}
