﻿using BankAccount_Task1;
using System.Globalization;
using System.Text;

internal static class Program
{
    /// <summary>
    /// Запускает программу.
    /// </summary>
    private static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("ru-RU");

        Console.WriteLine("1. IComparable: сортировка по балансу");

        var accounts = new List<BankAccount>
        {
            new("ACC-1", "Милана Кузнецова", 15_000m),
            new("ACC-2", "Алексей Сенченко", 42_000m),
            new("ACC-3", "Кирилл Мурзакаев", 7_500m)
        };

        Console.WriteLine("До сортировки:");
        PrintAccounts(accounts);

        accounts.Sort();

        Console.WriteLine("После сортировки:");
        PrintAccounts(accounts);

        Console.WriteLine();
        Console.WriteLine("2. ICloneable: глубокое клонирование");

        var original = new BankAccount("ACC-4", "Милана Кузнецова", 10_000m);
        var clone = (BankAccount)original.Clone();

        Console.WriteLine($"Оригинал: баланс {original.Balance:N2} Р, подключение #{original.Connection.Id}");
        Console.WriteLine($"Клон:     баланс {clone.Balance:N2} Р, подключение #{clone.Connection.Id}");

        clone.Deposit(5_000m);

        Console.WriteLine($"После пополнения клона: оригинал {original.Balance:N2} Р, клон {clone.Balance:N2} ₽");

        Console.WriteLine();
        Console.WriteLine("3. IEquatable: сравнение по номеру счeта");

        var first = new BankAccount("ACC-5", "Алексей Сенченко", 1_000m);
        var second = new BankAccount("acc-5", "Алексей Сенченко", 9_999m);

        Console.WriteLine($"first == second: {first == second}");
        Console.WriteLine($"first.Equals(second): {first.Equals(second)}");

        var checkList = new List<BankAccount> { first, second };
        Console.WriteLine($"List.Contains(second): {checkList.Contains(second)}");

        Console.WriteLine();
        Console.WriteLine("4. IDisposable: освобождение подключения");

        var accountForDispose = new BankAccount("ACC-6", "Кирилл Мурзакаев", 3_000m);
        Console.WriteLine($"До using: открыто = {accountForDispose.IsConnectionOpen}");

        using (accountForDispose)
        {
            Console.WriteLine($"Внутри using: открыто = {accountForDispose.IsConnectionOpen}");
        }

        Console.WriteLine($"После using: открыто = {accountForDispose.IsConnectionOpen}");

        Console.WriteLine();
        Console.WriteLine("5. Проверка входных данных");

        TryCreate("", "Милана Кузнецова", 1_000m);
        TryCreate("ACC-7", "   ", 1_000m);
        TryCreate("ACC-8", "Алексей Сенченко", -100m);

        var testAccount = new BankAccount("ACC-9", "Кирилл Мурзакаев", 1_000m);
        Console.WriteLine($"Пополнение на -500: {testAccount.Deposit(-500m)}");
        Console.WriteLine($"Снятие 5 000 при балансе 1 000: {testAccount.Withdraw(5_000m)}");
    }

    /// <summary>
    /// Печатает список счетов.
    /// </summary>
    private static void PrintAccounts(List<BankAccount> accounts)
    {
        foreach (BankAccount account in accounts)
        {
            Console.WriteLine("  " + account);
        }
    }

    /// <summary>
    /// Пытается создать счет и выводит ошибку, если данные некорректны.
    /// </summary>

    private static void TryCreate(string accountNumber, string owner, decimal initialBalance)
    {
        try
        {
            var account = new BankAccount(accountNumber, owner, initialBalance);
            Console.WriteLine($"Счет создан: {account}");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Некорректные данные: {ex.Message}");
        }
    }
}
