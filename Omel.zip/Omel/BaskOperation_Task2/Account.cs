﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BaskOperation_Task2;
public abstract class Account
{
    private readonly string _owner;
    private decimal _balance;

    /// <summary>
    /// Создаeт счет с владельцем и начальным балансом.
    /// </summary>
    /// <param name="owner">Владелец счета.</param>

    protected Account(string owner, decimal initialBalance)
    {
        if (string.IsNullOrWhiteSpace(owner))
        {
            throw new ArgumentException("Владелец счета не может быть пустым.", nameof(owner));
        }

        if (initialBalance < 0m)
        {
            throw new ArgumentException("Начальный баланс не может быть отрицательным.", nameof(initialBalance));
        }

        _owner = owner.Trim();
        _balance = initialBalance;
    }

    /// <summary>Владелец счета.</summary>
    public string Owner => _owner;

    /// <summary>Текущий баланс счета.</summary>
    public decimal Balance => _balance;

    /// <summary>
    /// Проверяет, что сумма операции положительна и не превышает разумный лимит.
    protected static bool IsValidAmount(decimal amount)
    {
        return amount > 0m && amount <= 1_000_000m;
    }

    /// <summary>Увеличивает баланс на корректную сумму.</summary>

    protected void IncreaseBalance(decimal amount)
    {
        _balance += amount;
    }

    /// <summary>Уменьшает баланс на корректную сумму.</summary>
    protected void DecreaseBalance(decimal amount)
    {
        _balance -= amount;
    }
}
