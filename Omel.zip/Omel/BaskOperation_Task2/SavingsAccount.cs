﻿namespace BaskOperation_Task2;

/// <summary>
/// Сберегательный счет.
/// Правила: пополнение не меньше 100 Р, при снятии на счете
/// должен оставаться неснижаемый остаток 500 Р.
/// </summary>
public sealed class SavingsAccount : Account, ITransactionable
{
    private const decimal MinimumDeposit = 100m;
    private const decimal MinimumBalance = 500m;

    /// <summary>
    /// Создаeт сберегательный счет.
    /// </summary>
    public SavingsAccount(string owner, decimal initialBalance)
        : base(owner, initialBalance)
    {
    }

    /// <summary>
    /// Пополняет счeт. Минимальная сумма пополнения — 100 P.

    public bool Deposit(decimal amount)
    {
        if (!IsValidAmount(amount) || amount < MinimumDeposit)
        {
            return false;
        }

        IncreaseBalance(amount);
        return true;
    }

    /// <summary>
    /// Снимает деньги, сохраняя неснижаемый остаток 500 P.
    /// </summary>

    public bool Withdraw(decimal amount)
    {
        if (!IsValidAmount(amount))
        {
            return false;
        }

        if (Balance - amount < MinimumBalance)
        {
            return false;
        }

        DecreaseBalance(amount);
        return true;
    }

    /// <summary>
    /// Возвращает описание сберегательного счeта.
    /// </summary>

    public string GetAccountInfo()
    {
        return $"Сберегательный счет | владелец: {Owner} | баланс: {Balance:N2} Р | " +
               $"минимальное пополнение: {MinimumDeposit:N2} Р | неснижаемый остаток: {MinimumBalance:N2} Р";
    }
}
