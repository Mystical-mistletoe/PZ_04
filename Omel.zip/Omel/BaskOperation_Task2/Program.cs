﻿using BaskOperation_Task2;
using System.Globalization;
using System.Text;

internal static class Program
{
    /// <summary>
    /// Запускает программу.
    /// </summary>
    private static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("ru-RU");

        var accounts = new List<ITransactionable>
        {
            new SavingsAccount("Милана Кузнецова", 10_000m),
            new CreditAccount("Алексей Сенченко", 2_000m, 30_000m),
            new SavingsAccount("Кирилл Мурзакаев", 800m),
            new CreditAccount("Анна Петрова", 0m, 15_000m)
        };

        Console.WriteLine("1. Счета до операций");
        PrintAccounts(accounts);

        Console.WriteLine();
        Console.WriteLine("2. Пополнение на 1 000 Р");

        foreach (ITransactionable account in accounts)
        {
            bool result = account.Deposit(1_000m);
            Console.WriteLine($"  {account.Owner}: {(result ? "выполнено" : "отклонено")}, баланс {account.Balance:N2} Р");
        }

        Console.WriteLine();
        Console.WriteLine("3. Снятие 5 000 Р");

        foreach (ITransactionable account in accounts)
        {
            bool result = account.Withdraw(5_000m);
            Console.WriteLine($"  {account.Owner}: {(result ? "выполнено" : "отклонено")}, баланс {account.Balance:N2} р");
        }

        Console.WriteLine();
        Console.WriteLine("4. Проверка данных");

        var savings = new SavingsAccount("Милана Кузнецова", 1_000m);
        Console.WriteLine($"  Пополнение -100: {savings.Deposit(-100m)}");
        Console.WriteLine($"  Пополнение 50: {savings.Deposit(50m)}");
        Console.WriteLine($"  Снятие 1 000 000: {savings.Withdraw(1_000_000m)}");

        TryCreateSavings("", 1_000m);
        TryCreateSavings("Алексей Сенченко", -1m);
        TryCreateCredit("Кирилл Мурзакаев", 0m, -100m);

        Console.WriteLine();
        Console.WriteLine("5. Счета после операций");
        PrintAccounts(accounts);
    }

    /// <summary>
    /// Печатает счета через интерфейс ITransactionable.
    /// </summary>
    /// <param name="accounts">Коллекция счетов.</param>
    private static void PrintAccounts(List<ITransactionable> accounts)
    {
        foreach (ITransactionable account in accounts)
        {
            Console.WriteLine($"  {account.GetAccountInfo()}");
        }
    }

    /// <summary>
    /// Пытается создать сберегательный счет и выводит ошибку при некорректных данных.
    /// </summary>

    private static void TryCreateSavings(string owner, decimal initialBalance)
    {
        try
        {
            var account = new SavingsAccount(owner, initialBalance);
            Console.WriteLine($"  Счет создан: {account.GetAccountInfo()}");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"  Некорректные данные: {ex.Message}");
        }
    }

    /// <summary>
    /// Пытается создать кредитный счет и выводит ошибку при некорректных данных.
    /// </summary>

    private static void TryCreateCredit(string owner, decimal initialBalance, decimal creditLimit)
    {
        try
        {
            var account = new CreditAccount(owner, initialBalance, creditLimit);
            Console.WriteLine($"  Счет создан: {account.GetAccountInfo()}");
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"  Некорректные данные: {ex.Message}");
        }
    }
}
