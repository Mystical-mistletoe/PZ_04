﻿namespace BaskOperation_Task2;
/// <summary>
/// Пользовательский интерфейс банковской операции.
/// Содержит пять членов: два свойства и три метода.
/// Методы с реализацией по умолчанию намеренно не используются:
/// правила пополнения и снятия у каждого счёта свои, поэтому общая
/// реализация в интерфейсе только запутала бы код.
/// </summary>
public interface ITransactionable
{
    /// <summary>Владелец счёта.</summary>
    string Owner { get; }

    /// <summary>Текущий баланс счёта.</summary>
    decimal Balance { get; }

    /// <summary>
    /// Пополняет счeт.
    /// </summary>
    /// <param name="amount">Сумма пополнения.</param>
    /// <returns><c>true</c>, если операция выполнена; иначе <c>false</c>.</returns>
    bool Deposit(decimal amount);

    /// <summary>
    /// Снимает деньги со счeта.
    /// </summary>
    /// <param name="amount">Сумма снятия.</param>
    /// <returns><c>true</c>, если операция выполнена; иначе <c>false</c>.</returns>
    bool Withdraw(decimal amount);

    /// <summary>
    /// Возвращает описание счeта и его правил.
    /// </summary>
    /// <returns>Текстовая информация о счeте.</returns>
    string GetAccountInfo();
}
