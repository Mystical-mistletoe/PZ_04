﻿namespace BaskOperation_Task2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public sealed class CreditAccount : Account, ITransactionable
{
    private readonly decimal _creditLimit;

    /// <summary>
    /// Создаeт кредитный счeт.
    /// </summary>

    public CreditAccount(string owner, decimal initialBalance, decimal creditLimit)
        : base(owner, initialBalance)
    {
        if (creditLimit <= 0m)
        {
            throw new ArgumentException("Кредитный лимит должен быть больше нуля.", nameof(creditLimit));
        }

        _creditLimit = creditLimit;
    }

    /// <summary>Кредитный лимит счeта.</summary>
    public decimal CreditLimit => _creditLimit;

    /// <summary>
    /// Пополняет счeт: сумма идeт на уменьшение долга.
    /// </summary>

    public bool Deposit(decimal amount)
    {
        if (!IsValidAmount(amount))
        {
            return false;
        }

        IncreaseBalance(amount);
        return true;
    }

    /// <summary>
    /// Снимает деньги в пределах кредитного лимита.
    /// </summary>
    /// <param name="amount">Сумма снятия.</param>
    /// <returns><c>true</c>, если операция выполнена.</returns>
    public bool Withdraw(decimal amount)
    {
        if (!IsValidAmount(amount))
        {
            return false;
        }

        if (Balance - amount < -_creditLimit)
        {
            return false;
        }

        DecreaseBalance(amount);
        return true;
    }

    /// <summary>
    /// Возвращает описание кредитного счeта.
    /// </summary>
    /// <returns>Информация о владельце, балансе и кредитном лимите.</returns>
    public string GetAccountInfo()
    {
        return $"Кредитный счёт | владелец: {Owner} | баланс: {Balance:N2} Р | " +
               $"кредитный лимит: {_creditLimit:N2} Р";
    }
}